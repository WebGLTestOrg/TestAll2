System.register([], (function (exports, module) {
	'use strict';
	return {
		execute: (function () {

			var bullet_release_wasm = exports("default", 'assets/bullet.release.wasm-BIzkn7bF.wasm'); /* asset-hash:effe0a64 */

		})
	};
}));
